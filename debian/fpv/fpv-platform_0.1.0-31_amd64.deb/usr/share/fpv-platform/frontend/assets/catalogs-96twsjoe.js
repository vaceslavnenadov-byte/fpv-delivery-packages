import{a as o}from"./styles-BLqXswEj.js";const t=()=>o.get("/api/v1/catalog/cargo-types").then(a=>a.items),s=()=>o.get("/api/v1/catalog/drone-models").then(a=>a.items);export{s as a,t as l};
